﻿using UnityEngine;
using Verse;

namespace MultiApparel
{
    public class MultiApparelMod : Mod
    {
        public MultiApparelMod(ModContentPack content) : base(content)
        {
            GetSettings<MultiApparelSettings>();
        }

        public override string SettingsCategory() => "Dynamic Apparel";

        public override void DoSettingsWindowContents(Rect inRect)
        {
            base.DoSettingsWindowContents(inRect);
        }
    }
}